/*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/
/*
� [2025] Microchip Technology Inc. and its subsidiaries.
    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include <xc.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>


#define NUM_SCREENS     3
typedef enum {
    SCREEN_DIGITAL_IN,      // Show digital input from Hafsa
    SCREEN_ANALOG_IN,       // Show analog values from teammates
    SCREEN_SUMMARY          // Show all data summary
} screen_t;

// Global variables
volatile screen_t current_screen = SCREEN_DIGITAL_IN;
volatile uint8_t encoder_last_a = 0;
volatile uint8_t screen_needs_update = 1;

// LED toggle variables
uint16_t led_toggle_counter = 0;
uint8_t led_state = 0;


//================LCD Section======================
void LCD_Enable(void) {
    IO_RD0_SetHigh();  // EN pin high
    __delay_us(1);
    IO_RD0_SetLow();   // EN pin low
    __delay_us(100);
}

void LCD_Send_Nibble(uint8_t nibble) {
    // Set D4-D7 data pins
    if (nibble & 0x01) {
        IO_RD3_SetHigh();  // D4
    } else {
        IO_RD3_SetLow();
    }
    
    if (nibble & 0x02) {
        IO_RF1_SetHigh();  // D5
    } else {
        IO_RF1_SetLow();
    }
    
    if (nibble & 0x04) {
        IO_RF2_SetHigh();  // D6
    } else {
        IO_RF2_SetLow();
    }
    
    if (nibble & 0x08) {
        IO_RF3_SetHigh();  // D7
    } else {
        IO_RF3_SetLow();
    }
    
    LCD_Enable();
}

void LCD_Command(uint8_t cmd) {
    IO_RD1_SetLow();  // RS = 0 for command mode
    LCD_Send_Nibble(cmd >> 4);   // Send upper nibble
    LCD_Send_Nibble(cmd & 0x0F); // Send lower nibble
    __delay_ms(2);
}

void LCD_Data(uint8_t data) {
    IO_RD1_SetHigh();  // RS = 1 for data mode
    LCD_Send_Nibble(data >> 4);   // Send upper nibble
    LCD_Send_Nibble(data & 0x0F); // Send lower nibble
    __delay_us(100);
}

void LCD_Init(void) {
    // No port initialization needed - already done by MCC!
    __delay_ms(50);  // Wait for LCD to power up
    
    // Initialization sequence for 4-bit mode
    IO_RD1_SetLow();  // RS = 0
    LCD_Send_Nibble(0x03);
    __delay_ms(5);
    LCD_Send_Nibble(0x03);
    __delay_us(150);
    LCD_Send_Nibble(0x03);
    __delay_us(150);
    LCD_Send_Nibble(0x02);  // Switch to 4-bit mode
    __delay_us(150);
    
    // Function set: 4-bit, 2 lines, 5x8 dots
    LCD_Command(0x28);
    // Display ON, Cursor OFF, Blink OFF
    LCD_Command(0x0C);
    // Clear display
    LCD_Command(0x01);
    __delay_ms(2);
    // Entry mode: Increment cursor, no shift
    LCD_Command(0x06);
}

void LCD_Clear(void) {
    LCD_Command(0x01);
    __delay_ms(2);
}

void LCD_SetCursor(uint8_t row, uint8_t col) {
    uint8_t address;
    if (row == 0) {
        address = 0x80 + col;  // Row 0 starts at 0x00
    } else {
        address = 0xC0 + col;  // Row 1 starts at 0x40
    }
    LCD_Command(address);
}

void LCD_Print(const char* str) {
    while (*str) {
        LCD_Data(*str++);
    }
}

void LCD_Print_Number(uint16_t num) {
    char buffer[6];
    sprintf(buffer, "%u", num);
    LCD_Print(buffer);
}

// ===========Encoder Section===================
void Encoder_Init(void) {
    encoder_last_a = IO_RC5_GetValue();
}

int8_t Encoder_Read(void) {

    uint8_t a = IO_RC5_GetValue();  // Encoder A
    uint8_t b = IO_RC6_GetValue();  // Encoder B
    
    // Rotation detection
    if (a != encoder_last_a) {
        encoder_last_a = a;
        if (a == 0) {  // Falling edge on A
            if (b == 1) {
                return 1;   // Clockwise
            } else {
                return -1;  // Counter-clockwise
            }
        }
    }
    return 0;  // No rotation
}

// ==========LED Toggles===================

void Toggle_LEDs(void) {
    // Toggle all output LEDs
    if (led_state == 0) {
        IO_RF5_SetHigh();  // Michael 1
        IO_RE1_SetHigh();  // Michael 2
        IO_RB5_SetHigh();  // Levi
        IO_RF7_SetHigh();  // Hafsa
        led_state = 1;
    } else {
        IO_RF5_SetLow();
        IO_RE1_SetLow();
        IO_RB5_SetLow();
        IO_RF7_SetLow();
        led_state = 0;
    }
}

// ==========Display Screen Functions==========

void Display_Screen_Digital_In(uint8_t hafsa_in) {
    LCD_Clear();
    LCD_SetCursor(0, 0);
    LCD_Print("Digital Input");
    
    __delay_ms(2);  // Small delay between rows
    
    LCD_SetCursor(1, 0);
    LCD_Print("Hafsa: ");
    LCD_Print(hafsa_in ? "ON " : "OFF");
}

void Display_Screen_Analog_In(uint16_t levi_analog, uint16_t hafsa_analog) {
    LCD_Clear();
    LCD_SetCursor(0, 0);
    LCD_Print("Analog Inputs");
    
    __delay_ms(2);  // Small delay between rows
    
    LCD_SetCursor(1, 0);
    LCD_Print("L:");
    LCD_Print_Number(levi_analog);
    
    LCD_SetCursor(1, 9);
    LCD_Print("H:");
    LCD_Print_Number(hafsa_analog);
}

void Display_Screen_Summary(uint8_t hafsa_in, uint8_t led_on,
                            uint16_t levi_analog, uint16_t hafsa_analog) {
    LCD_Clear();
    
    // Row 0: Michael 1 and Michael 2 outputs
    LCD_SetCursor(0, 0);
    LCD_Print("M1:");
    LCD_Print(led_on ? "ON " : "OFF");
    LCD_Print(" M2:");
    LCD_Print(led_on ? "ON" : "OFF");
    
    __delay_ms(2);  // Small delay between rows
    
    // Row 1: Levi and Hafsa outputs
    LCD_SetCursor(1, 0);
    LCD_Print("L:");
    LCD_Print(led_on ? "ON  " : "OFF ");
    LCD_Print(" H:");
    LCD_Print(led_on ? "ON" : "OFF");
}

void Update_LCD_Display(uint8_t hafsa_in, uint8_t led_on,
                        uint16_t levi_analog, uint16_t hafsa_analog) {
    
    switch(current_screen) {
        case SCREEN_DIGITAL_IN:
            Display_Screen_Digital_In(hafsa_in);
            break;
            
        case SCREEN_ANALOG_IN:
            Display_Screen_Analog_In(levi_analog, hafsa_analog);
            break;
            
        case SCREEN_SUMMARY:
            Display_Screen_Summary(hafsa_in, led_on, levi_analog, hafsa_analog);
            break;
    }
    
    screen_needs_update = 0;
}

// Read analog signal from specified channel
uint16_t readAnalog(uint8_t channel) {
    uint16_t adcResult = 0;
    
    ADC_ChannelSelect(channel);
    
    ADC_ConversionStart();
    
    while (!ADC_IsConversionDone());
    
    adcResult = ADC_ConversionResultGet();
    
    return adcResult;
}

//Enable internal pullup resistors for my Encoder
void configureButtonPullups(void) {
    WPUCbits.WPUC5 = 1;  // RC5 - Encoder A
    WPUCbits.WPUC6 = 1;  // RC6 - Encoder B
}

// =============Main==============================
int main(void) {
    
    
    SYSTEM_Initialize();
    ADC_Initialize();
    INTERRUPT_GlobalInterruptEnable();
    UART1_Enable();
    configureButtonPullups();
    
    // Initialize LCD and Rotary Encoder
    LCD_Init();
    Encoder_Init();
    
    // Display welcome message
    LCD_Clear();
    LCD_SetCursor(0, 0);
    LCD_Print("Team Project");
    LCD_SetCursor(1, 0);
    LCD_Print("Initializing...");
    __delay_ms(2000);
    
    // Analog variables
    uint16_t levi_analog_in = 0;
    uint16_t hafsa_analog_in = 0;
    
    // Digital state variables
    uint8_t hafsa_digital = 0;
    
    // Update counter for periodic LCD refresh
    uint8_t update_counter = 0;
    
    while(1) {
        
        // ========= Read Rotary Encoder ================
        int8_t rotation = Encoder_Read();
        if (rotation > 0) {
            // Clockwise - Next screen
            current_screen = (current_screen + 1) % NUM_SCREENS;
            screen_needs_update = 1;
        } else if (rotation < 0) {
            // Counter-clockwise - Previous screen
            if (current_screen == 0) {
                current_screen = NUM_SCREENS - 1;
            } else {
                current_screen--;
            }
            screen_needs_update = 1;
        }     
        
        // ========Recieving Digital Signal================
        
        // Hafsa digital input
        hafsa_digital = IO_RF6_GetValue();
        if(hafsa_digital == 1) {
            // IO_LEDx_SetHigh();
        }
        else {
            // IO_LEDx_SetLow();
        }
        
        
        // ========Sending Digital Signals===============
        
        led_toggle_counter++;
        if (led_toggle_counter >= 20) {
            Toggle_LEDs();
            led_toggle_counter = 0;
        }
        
        
        // =========Receiving Analog Signals================
        
        // Read Levi's signal (on ANA2)
        levi_analog_in = readAnalog(ADC_CHANNEL_ANA2);
        
        // Read Hafsa's signal (on ANA1)
        hafsa_analog_in = readAnalog(ADC_CHANNEL_ANA0);
        
        
        // =========Update LCD Display=================
        update_counter++;
        if (screen_needs_update || update_counter >= 10) {
            Update_LCD_Display(hafsa_digital, led_state,
                              levi_analog_in, hafsa_analog_in);
            update_counter = 0;
        }
        
        
        // ======Print to UART for testing (maybe)======================
        // Display the analog values in putty
        // printf("Levi Analog: %u | Hafsa Analog: %u\r\n", levi_analog_in, hafsa_analog_in);
        
        __delay_ms(50);  // Reduced delay for faster response
       
    }
     
        
}